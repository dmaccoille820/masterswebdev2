-- lsof -t -i:3000   kill -9 <PID>
-- Connection command 
-- /home/user/masterswebdev2/mysql-project-idx/start.sh  
-- mysql -S mysql-project-idx/data/mysql.sock -uroot -p123456
-- after user 21 register
-- INSERT INTO project (project_name, project_type, project_description, user_id) VALUES
-- ('Build a website', 'projects', 'Create a personal portfolio website', 21)
-- Tasks for project 21: Build a website
--INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
--(28, 'Create wireframe', 'Design the wireframe for the website', '2025-02-01', 'High', 'Not Started'),
--(28, 'Develop homepage', 'Code the homepage using HTML, CSS, and JavaScript', '2025-02-05', 'High', 'Not Started'),
--(28, 'Create contact form', 'Develop a contact form for the website', '2025-02-10', 'Medium', 'Not Started'),
--(28, 'Test website', 'Test the website for bugs and errors', '2025-02-15', 'Medium', 'Not Started'),
--(28, 'Deploy website', 'Deploy the website to a hosting service', '2025-02-20', 'Medium', 'Not Started'),
--(28, 'Promote website', 'Create a marketing plan to promote the website', '2025-02-25', 'Low', 'Not Started');



DROP DATABASE IF EXISTS TaskTracker;
-- Create the TaskTracker database
CREATE DATABASE TaskTracker;

-- Use the TaskTracker database
USE TaskTracker;
-- Create the users table
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  username VARCHAR(255) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);
INSERT INTO users (name, username, email, password) VALUES
('Alice Johnson', 'alicej', 'alice.johnson@email.com', '$2b$10$9c0n21Vz4kO7uLhF9G5XW.example1'),
('Bob Williams', 'bobw', 'bob.williams@email.com', '$2b$10$a8Q1z6YjR3sH2uK5yLhMv.example2'),
('Charlie Brown', 'charlieb', 'charlie.brown@email.com', '$2b$10$b7R2x5IzD4pW1uJ6zKcYp.example3'),
('Diana Davis', 'dianad', 'diana.davis@email.com', '$2b$10$c9E3y4JxV5oG8uK7nLtQn.example4'),
('Ethan Miller', 'ethanm', 'ethan.miller@email.com', '$2b$10$d6F4v3KyJ2lP9uQ8pMsOo.example5'),
('Fiona Wilson', 'fionaw', 'fiona.wilson@email.com', '$2b$10$e5G5w2LxK7mR0uP9oNsQv.example6'),
('George Taylor', 'georget', 'george.taylor@email.com', '$2b$10$f4H6x1MzL8nS1uO9qOtRw.example7'),
('Hannah Anderson', 'hannah', 'hannah.anderson@email.com', '$2b$10$g3I7y0NzM9oT2uP0rPuSy.example8'),
('Ian Thomas', 'iant', 'ian.thomas@email.com', '$2b$10$h2J8z9OyN0lU3uQ1sQvTx.example9'),
('Julia Martinez', 'juliam', 'julia.martinez@email.com', '$2b$10$i1K9w8PxO1mV4uN2tRuUy.example10'),
('Kevin Garcia', 'keving', 'kevin.garcia@email.com', '$2b$10$j0L0x7QwN2uU5vO3wStVz.example11'),
('Laura Rodriguez', 'laurar', 'laura.rodriguez@email.com', '$2b$10$k9M1y6PxN3oV4uP5wTuUw.example12'),
('Mike Hernandez', 'mikeh', 'mike.hernandez@email.com', '$2b$10$l8N2z5OyM4oW3uR6xSvVx.example13'),
('Nancy Lopez', 'nancyl', 'nancy.lopez@email.com', '$2b$10$m7O3x4NzV5pT2uS7yRwUv.example14'),
('Oliver Green', 'oliverg', 'oliver.green@email.com', '$2b$10$n6P4y3PxM6uU1vO8xQuTw.example15'),
('Pamela Baker', 'pamelab', 'pamela.baker@email.com', '$2b$10$o5Q5z2OyN7pW0uR9vPrUz.example16'),
('Quentin Adams', 'quentina', 'quentin.adams@email.com', '$2b$10$p4R6x1MzL8nS1uP0qOtRw.example17'),
('Rachel Nelson', 'racheln', 'rachel.nelson@email.com', '$2b$10$q3S7y0NzM9oT2uP0rPuSy.example18'), 
('Samuel Carter', 'samuelc', 'samuel.carter@email.com', '$2b$10$r2T8z9OyN0lU3uQ1sQvTx.example19'),
('Tina Perez', 'tinap', 'tina.perez@email.com', '$2b$10$s1U9w8PxO1mV4uN2tRuUy.example20')
;
-- Create the project table
CREATE TABLE project (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL,
    project_type varchar(255),
    project_description VARCHAR(255) NOT NULL ,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

INSERT INTO project (project_name, project_type, project_description, user_id) VALUES
('Build a website', 'projects', 'Create a personal portfolio website', 1),
('Learn Spanish', 'personal goals', 'Complete an online Spanish course', 2),
('Grocery shopping', 'everyday activities', 'Weekly grocery shopping at the local market', 3),
('Develop a mobile app', 'projects', 'Create a mobile app for task tracking', 4),
('Run a marathon', 'personal goals', 'Train and complete a marathon', 5),
('Cleaning the house', 'everyday activities', 'Weekly house cleaning routine', 6),
('Create a marketing plan', 'projects', 'Develop a marketing strategy for a new product', 7),
('Read 12 books in a year', 'personal goals', 'Read one book each month for a year', 8),
('Exercise', 'everyday activities', 'Daily workout routine', 9),
('Design a logo', 'projects', 'Create a new logo for a startup', 10),
('Meditate daily', 'personal goals', 'Incorporate daily meditation into routine', 11),
('Laundry', 'everyday activities', 'Weekly laundry task', 12),
('Write a blog', 'projects', 'Start a personal blog and write articles', 13),
('Save money', 'personal goals', 'Save a specific amount of money each month', 14),
('Cook meals', 'everyday activities', 'Prepare healthy meals at home', 15),
('Build a robot', 'projects', 'Construct a simple robot as a hobby project', 16),
('Lose weight', 'personal goals', 'Follow a diet and exercise plan to lose weight', 17),
('Gardening', 'everyday activities', 'Take care of the garden and plants', 18),
('Create an online course', 'projects', 'Develop and launch an online course', 19),
('Travel', 'personal goals', 'Plan and take a trip to a new destination', 20),
('Organize files', 'everyday activities', 'Organize and declutter digital files', 1),
('Paint a mural', 'projects', 'Create a large mural for a community project', 2),
('Learn to play guitar', 'personal goals', 'Take guitar lessons and practice regularly', 3),
('Pay bills', 'everyday activities', 'Ensure all monthly bills are paid on time', 4),
('Develop a game', 'projects', 'Create a simple video game', 5),
('Improve public speaking', 'personal goals', 'Join a public speaking club and practice', 6),
('Daily journaling', 'everyday activities', 'Write in a journal every day', 7);


-- Create the tasks table
CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    priority VARCHAR(255) DEFAULT 'Medium',
    completion_status VARCHAR(255) DEFAULT 'Not Started',
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES project(project_id)
);

-- Tasks for project 1: Build a website
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(1, 'Create wireframe', 'Design the wireframe for the website', '2025-02-01', 'High', 'Not Started'),
(1, 'Develop homepage', 'Code the homepage using HTML, CSS, and JavaScript', '2025-02-05', 'High', 'Not Started'),
(1, 'Create contact form', 'Develop a contact form for the website', '2025-02-10', 'Medium', 'Not Started'),
(1, 'Test website', 'Test the website for bugs and errors', '2025-02-15', 'Medium', 'Not Started'),
(1, 'Deploy website', 'Deploy the website to a hosting service', '2025-02-20', 'Medium', 'Not Started'),
(1, 'Promote website', 'Create a marketing plan to promote the website', '2025-02-25', 'Low', 'Not Started');

-- Tasks for project 2: Learn Spanish
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(2, 'Enroll in course', 'Find and enroll in an online Spanish course', '2025-02-01', 'High', 'Not Started'),
(2, 'Daily practice', 'Practice Spanish daily using language apps', '2025-02-28', 'High', 'Not Started'),
(2, 'Watch Spanish movies', 'Watch Spanish movies with subtitles', '2025-03-10', 'Medium', 'Not Started'),
(2, 'Join language exchange', 'Join a language exchange community', '2025-03-20', 'Medium', 'Not Started'),
(2, 'Practice speaking', 'Practice speaking with native Spanish speakers', '2025-03-30', 'High', 'Not Started'),
(2, 'Take progress test', 'Take a test to assess progress in Spanish', '2025-04-10', 'Medium', 'Not Started');

-- Tasks for project 3: Grocery shopping
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(3, 'Make a list', 'Create a list of items needed', '2025-01-20', 'High', 'Not Started'),
(3, 'Check discounts', 'Check for discounts and offers', '2025-01-22', 'Medium', 'Not Started'),
(3, 'Visit store', 'Go to the grocery store to shop', '2025-01-25', 'High', 'Not Started'),
(3, 'Buy fresh produce', 'Ensure to buy fresh fruits and vegetables', '2025-01-25', 'High', 'Not Started'),
(3, 'Purchase dairy', 'Buy dairy products like milk and cheese', '2025-01-25', 'Medium', 'Not Started'),
(3, 'Organize groceries', 'Organize and store groceries properly', '2025-01-25', 'Medium', 'Not Started');

-- Tasks for project 4: Develop a mobile app
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(4, 'Plan app features', 'Outline the key features of the mobile app', '2025-02-01', 'High', 'Not Started'),
(4, 'Design UI/UX', 'Create the UI/UX design for the app', '2025-02-10', 'High', 'Not Started'),
(4, 'Develop backend', 'Set up the backend infrastructure', '2025-02-20', 'High', 'Not Started'),
(4, 'Code frontend', 'Develop the frontend interface', '2025-03-01', 'Medium', 'Not Started'),
(4, 'Test app', 'Perform testing to find and fix bugs', '2025-03-10', 'Medium', 'Not Started'),
(4, 'Launch app', 'Launch the app on app stores', '2025-03-20', 'High', 'Not Started');

-- Tasks for project 5: Run a marathon
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(5, 'Research marathons', 'Find marathons to participate in', '2025-02-01', 'Medium', 'Not Started'),
(5, 'Create training plan', 'Develop a training plan for running', '2025-02-05', 'High', 'Not Started'),
(5, 'Buy running gear', 'Purchase appropriate running shoes and clothes', '2025-02-10', 'Medium', 'Not Started'),
(5, 'Daily runs', 'Go for daily training runs', '2025-02-15', 'High', 'Not Started'),
(5, 'Track progress', 'Track running progress and improve', '2025-03-01', 'Medium', 'Not Started'),
(5, 'Participate in marathon', 'Complete the chosen marathon', '2025-03-20', 'High', 'Not Started');

-- Tasks for project 6: Cleaning the house 
INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES 
(6, 'Declutter rooms', 'Remove clutter from all rooms', '2025-01-15', 'High', 'Not Started'), 
(6, 'Dust surfaces', 'Dust all surfaces including shelves and tables', '2025-01-18', 'Medium', 'Not Started'), 
(6, 'Vacuum carpets', 'Vacuum all carpets and rugs', '2025-01-20', 'High', 'Not Started'), 
(6, 'Mop floors', 'Mop all hard floors', '2025-01-22', 'Medium', 'Not Started'), 
(6, 'Clean kitchen', 'Deep clean the kitchen area', '2025-01-25', 'High', 'Not Started'), 
(6, 'Organize storage', 'Organize storage areas like closets and cabinets', '2025-01-28', 'Medium', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES 
(7, 'Market research', 'Conduct market research to understand the target audience', '2025-02-01', 'High', 'Not Started'),
(7, 'Competitor analysis', 'Analyze competitors and their marketing strategies', '2025-02-05', 'Medium', 'Not Started'),
(7, 'Develop strategy', 'Develop a comprehensive marketing strategy', '2025-02-10', 'High', 'Not Started'),
(7, 'Create content plan', 'Plan and create marketing content', '2025-02-15', 'Medium', 'Not Started'),
(7, 'Launch campaign', 'Launch the marketing campaign', '2025-02-20', 'High', 'Not Started'),
(7, 'Measure results', 'Measure the results and adjust the strategy accordingly', '2025-02-25', 'Medium', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(8, 'Select books', 'Select 12 books to read this year', '2025-01-01', 'High', 'Not Started'),
(8, 'Read book 1', 'Read the first book', '2025-01-31', 'High', 'Not Started'),
(8, 'Read book 2', 'Read the second book', '2025-02-28', 'High', 'Not Started'),
(8, 'Read book 3', 'Read the third book', '2025-03-31', 'High', 'Not Started'),
(8, 'Read book 4', 'Read the fourth book', '2025-04-30', 'High', 'Not Started'),
(8, 'Read book 5', 'Read the fifth book', '2025-05-31', 'High', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(9, 'Plan workout', 'Create a weekly workout plan', '2025-01-05', 'High', 'Not Started'),
(9, 'Cardio exercises', 'Include cardio exercises like running or cycling', '2025-01-10', 'High', 'Not Started'),
(9, 'Strength training', 'Include strength training exercises', '2025-01-15', 'High', 'Not Started'),
(9, 'Flexibility exercises', 'Include flexibility exercises like stretching or yoga', '2025-01-20', 'Medium', 'Not Started'),
(9, 'Track progress', 'Track your workout progress', '2025-01-25', 'Medium', 'Not Started'),
(9, 'Adjust plan', 'Adjust the workout plan based on progress', '2025-01-30', 'Medium', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(10, 'Research logos', 'Research existing logos for inspiration', '2025-01-01', 'Medium', 'Not Started'),
(10, 'Sketch ideas', 'Sketch initial logo ideas', '2025-01-05', 'High', 'Not Started'),
(10, 'Create drafts', 'Create digital drafts of the logo', '2025-01-10', 'High', 'Not Started'),
(10, 'Get feedback', 'Get feedback on the drafts from stakeholders', '2025-01-15', 'Medium', 'Not Started'),
(10, 'Revise logo', 'Revise the logo based on feedback', '2025-01-20', 'High', 'Not Started'),
(10, 'Finalize logo', 'Finalize the logo design', '2025-01-25', 'High', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(11, 'Set time', 'Choose a time for daily meditation', '2025-01-01', 'High', 'Not Started'),
(11, 'Find a spot', 'Choose a quiet spot for meditation', '2025-01-02', 'High', 'Not Started'),
(11, 'Start meditation', 'Start with 10 minutes of meditation daily', '2025-01-03', 'High', 'Not Started'),
(11, 'Increase duration', 'Gradually increase meditation duration', '2025-01-10', 'Medium', 'Not Started'),
(11, 'Try guided meditation', 'Try guided meditation sessions', '2025-01-15', 'Medium', 'Not Started'),
(11, 'Track progress', 'Track your meditation progress and its effects', '2025-01-20', 'Medium', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(12, 'Sort clothes', 'Sort clothes by color and fabric type', '2025-01-05', 'Medium', 'Not Started'),
(12, 'Wash clothes', 'Wash clothes using appropriate settings', '2025-01-06', 'High', 'Not Started'),
(12, 'Dry clothes', 'Dry clothes using a dryer or air dry', '2025-01-07', 'Medium', 'Not Started'),
(12, 'Iron clothes', 'Iron clothes that need to be ironed', '2025-01-08', 'Medium', 'Not Started'),
(12, 'Fold clothes', 'Fold all dried and ironed clothes', '2025-01-09', 'Medium', 'Not Started'),
(12, 'Put away clothes', 'Put away all folded clothes in their places', '2025-01-10', 'Medium', 'Not Started');

INSERT INTO tasks (project_id, name, description, due_date, priority, completion_status) VALUES
(13, 'Choose a topic', 'Select a topic to blog about', '2025-01-01', 'High', 'Not Started'),
(13, 'Create a schedule', 'Create a blogging schedule', '2025-01-05', 'Medium', 'Not Started'),
(13, 'Write first post', 'Write the first blog post', '2025-01-10', 'High', 'Not Started'),
(13, 'Edit post', 'Edit and proofread the blog post', '2025-01-15', 'Medium', 'Not Started'),
(13, 'Publish post', 'Publish the blog post', '2025-01-20', 'High', 'Not Started'),
(13, 'Promote blog', 'Promote the blog on social media', '2025-01-25', 'Medium', 'Not Started');
CREATE TABLE sessions (

    session_id VARCHAR(255) PRIMARY KEY,
    user_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL 3600 SECOND),
    isValid INT DEFAULT 2,  -- 1 is valid 2 is temporary for a login attempt. 0 is invalid
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);



CREATE VIEW UserProjectsTasks AS
SELECT 
    u.user_id,
    u.name AS user_name,
    u.username,
    p.project_id,
    p.project_name,
    p.project_type,
    p.project_description,
    t.task_id,
    t.name AS task_name,
    t.description AS task_description,
    t.due_date,
    t.priority,
    t.completion_status,
    t.creation_date AS task_creation_date
FROM 
    users u
    JOIN project p ON u.user_id = p.user_id
    JOIN tasks t ON p.project_id = t.project_id ;


DELIMITER //

CREATE PROCEDURE GetUserProjectsTasksByUserId(
    IN p_user_id INT
)
BEGIN
    SELECT 
        user_id,
        user_name,
        username,
        project_id,
        project_name,
    project_type,
    project_description,
        task_id,
        task_name,
        task_description,
        due_date,
        priority,
        completion_status,
        task_creation_date
    FROM 
        UserProjectsTasks
    WHERE 
        user_id = p_user_id;
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE GetUserProjectsTasksNextWeek(
    IN p_user_id INT
)
BEGIN
    SELECT task_name, due_date, priority, completion_status
    FROM UserProjectsTasks
    WHERE user_id = p_user_id
    AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    AND due_date >= CURDATE();
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE FindUserByUsernameOrEmail(  
    IN usernameOrEmail VARCHAR(255),  
    OUT user_id_out INT
)  
BEGIN  
    SELECT user_id INTO user_id_out 
    FROM users
    WHERE username = usernameOrEmail OR email = usernameOrEmail;
    
    IF user_id_out IS NULL THEN
        SET user_id_out = -1; 
    END IF;
    select user_id_out;
END //
DELIMITER ;
DELIMITER //
-- Modify the findUserById stored procedure to return the data as SELECT p_name, p_username, p_email, p_password instead of using the INTO clause. Also remove any out parameter. The data should be returned as a result set, not by OUT parameters
CREATE PROCEDURE FindUserById(
    IN p_user_id INT
)
BEGIN
    SELECT user_id, name, username, email, password FROM users
    WHERE user_id = p_user_id;

   
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE RegisterUser(
    IN p_name VARCHAR(255),
    IN p_username VARCHAR(255),
    IN p_email VARCHAR(255),
    IN p_password VARCHAR(255),
    OUT p_user_id INT
)
BEGIN
    INSERT INTO users (name, username, email, password)
    VALUES (p_name, p_username, p_email, p_password);
    SET p_user_id = LAST_INSERT_ID();
END //

DELIMITER ;




DELIMITER //

CREATE TRIGGER before_session_insert
BEFORE INSERT ON sessions
FOR EACH ROW
BEGIN
    SET NEW.expires_at = CURRENT_TIMESTAMP + INTERVAL 3600 SECOND;
END;

//

DELIMITER ;



-- Stored procedure to validate a session and return the user ID
DELIMITER //
CREATE PROCEDURE ValidateSession(
    IN p_session_id VARCHAR(255)
)
BEGIN
    DECLARE nowTimestamp BIGINT;
    DECLARE sessionExpiresTimestamp BIGINT;
    DECLARE retrievedUserId INT;

    -- Check if the session exists
    IF EXISTS (SELECT 1 FROM sessions WHERE session_id = p_session_id) THEN
        -- The session exists, let's validate
        SELECT UNIX_TIMESTAMP(expires_at), user_id INTO sessionExpiresTimestamp, retrievedUserId FROM sessions WHERE session_id = p_session_id;
        SET nowTimestamp = UNIX_TIMESTAMP();
        -- Is the session expired?
        IF nowTimestamp > sessionExpiresTimestamp THEN
                -- Session is expired
                -- Return null user 
                SELECT NULL as userId;
        ELSE
                -- Session is valid
                -- Update the session expiration
                UPDATE sessions SET expires_at = FROM_UNIXTIME(nowTimestamp + 3600) WHERE session_id = p_session_id;
                 -- Return the user ID
                 SELECT retrievedUserId as userId;
        END IF;
    ELSE
        -- the session does not exist
        -- Return null user 
         SELECT NULL as userId;
    END IF;
END //
DELIMITER ;



DELIMITER //
-- Stored procedure to create a new session
CREATE PROCEDURE CreateSession(
    OUT p_session_id VARCHAR(255),
    IN p_user_id INT
)
BEGIN
    -- Generate a new unique session ID
    SET p_session_id = UUID();
    -- Create a new session in the sessions table and associate it with the user
    INSERT INTO sessions (session_id, user_id, expires_at)
    VALUES (p_session_id, p_user_id, FROM_UNIXTIME(UNIX_TIMESTAMP() + 3600));
    
    UPDATE sessions SET isValid = 1 WHERE session_id = p_session_id;
    SELECT p_session_id;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CheckUsernameOrEmailAvailability(
    IN p_username VARCHAR(255),
    IN p_email VARCHAR(255),
    OUT p_isAvailable INT
)
BEGIN
    -- Check if username exists
    IF EXISTS (SELECT 1 FROM users WHERE username = p_username) THEN
        SET p_isAvailable = -1; -- Username taken
    -- Check if email exists
    ELSEIF EXISTS (SELECT 1 FROM users WHERE email = p_email) THEN
        SET p_isAvailable = -2; -- Email taken
    ELSE
        SET p_isAvailable = 1;  -- Username and email available
    END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE UpdateSessionUser(
    IN p_session_id VARCHAR(255),
    IN p_user_id INT
)
BEGIN
    UPDATE sessions
    SET user_id = p_user_id
    WHERE session_id = p_session_id;
END //

DELIMITER ;



DELIMITER //
CREATE PROCEDURE InsertTask (
    IN p_project_id INT,
    IN p_name VARCHAR(255),
    IN p_description TEXT,
    IN p_due_date DATE,
    IN p_priority VARCHAR(255),
    IN p_completion_status VARCHAR(255)
)
BEGIN
    INSERT INTO tasks (
        project_id,
        name,
        description,
        due_date,
        priority,
        completion_status
    ) VALUES (
        p_project_id,
        p_name,
        p_description,
        p_due_date,
        p_priority,
        p_completion_status
    );
END //
DELIMITER ;


DELIMITER //
CREATE PROCEDURE UpdateTask (
    IN p_task_id INT,
    IN p_project_id INT,
    IN p_name VARCHAR(255),
    IN p_description TEXT,
    IN p_due_date DATE,
    IN p_priority VARCHAR(255),
    IN p_completion_status VARCHAR(255)
)
BEGIN
    UPDATE tasks
    SET 
        
        name = p_name,
        description = p_description,
        due_date = p_due_date,
        priority = p_priority,
        completion_status = p_completion_status
    WHERE 
        task_id = p_task_id;
END //
DELIMITER ;


DELIMITER //
CREATE PROCEDURE DeleteTask (
    IN p_task_id INT
)
BEGIN
    DELETE FROM tasks
    WHERE task_id = p_task_id;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE DeleteSession (
    IN p_session_id VARCHAR(255)
)
BEGIN
    DELETE FROM sessions WHERE session_id = p_session_id;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE GetUserProjectsByUserId(IN p_userId INT) 
BEGIN SELECT p.project_id, p.project_name, 
p.project_description, 
COUNT(t.task_id) AS task_count, 
COALESCE(SUM(CASE WHEN t.completion_status = 'Completed' THEN 1 ELSE 0 END) / COUNT(t.task_id), 0) 
AS completion_percentage, 
CASE WHEN COUNT(t.task_id) = 0 
THEN 'Not Started' 
WHEN SUM(CASE WHEN t.completion_status = 'Completed' 
THEN 1 ELSE 0 END) = COUNT(t.task_id) THEN 'Completed' 
ELSE 'In Progress' END AS project_status, 
(SELECT MAX(due_date) FROM tasks WHERE project_id = p.project_id) 
AS latest_due_date FROM project p 
LEFT JOIN tasks t ON p.project_id = t.project_id 
WHERE p.user_Id = p_userId 
GROUP BY p.project_id, p.project_name, p.project_description; 
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE GetTaskProgressByUserId(IN p_userId INT)
BEGIN
    SELECT
        SUM(CASE WHEN t.completion_status = 'Completed' THEN 1 ELSE 0 END) as completed,
        COUNT(t.task_id) as total
    FROM
        tasks t
    JOIN project p ON t.project_id = p.project_id
    WHERE p.user_id = p_userId;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE GetTasksByProjectId(IN p_project_id INT)
BEGIN
    SELECT
        *
    FROM
        tasks t
    WHERE t.project_id = p_project_id;
END //

DELIMITER ;
